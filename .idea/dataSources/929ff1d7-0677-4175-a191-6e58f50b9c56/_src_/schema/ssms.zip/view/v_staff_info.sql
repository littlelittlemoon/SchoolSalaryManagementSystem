CREATE VIEW `v_staff_info` AS
  SELECT
    `ssms`.`t_staff_info`.`staff_id`           AS `staff_id`,
    `ssms`.`t_staff_info`.`staff_name`         AS `staff_name`,
    `ssms`.`t_staff_info`.`staff_sex`          AS `staff_sex`,
    `ssms`.`t_department`.`department_name`    AS `department_name`,
    `ssms`.`t_staff_info`.`staff_tel`          AS `staff_tel`,
    `ssms`.`t_staff_info`.`staff_identity_num` AS `staff_identity_num`,
    `ssms`.`t_title`.`title_name`              AS `title_name`,
    `ssms`.`t_duty`.`duty_name`                AS `duty_name`,
    `ssms`.`t_staff_info`.`staff_bank_acount`  AS `staff_bank_acount`,
    `ssms`.`t_staff_info`.`staff_entry_time`   AS `staff_entry_time`,
    `ssms`.`t_role`.`role_name`                AS `role_name`,
    `ssms`.`t_duty`.`duty_salary`              AS `duty_salary`,
    `ssms`.`t_title`.`title_salary`            AS `title_salary`,
    `ssms`.`t_title`.`title_basesalary`        AS `title_basesalary`
  FROM `ssms`.`t_staff_info`
    JOIN `ssms`.`t_role`
    JOIN `ssms`.`t_department`
    JOIN `ssms`.`t_title`
    JOIN `ssms`.`t_duty`
  WHERE ((`ssms`.`t_staff_info`.`role_id` = `ssms`.`t_role`.`role_id`) AND
         (`ssms`.`t_staff_info`.`duty_id` = `ssms`.`t_duty`.`duty_id`) AND
         (`ssms`.`t_staff_info`.`department_id` = `ssms`.`t_department`.`department_id`) AND
         (`ssms`.`t_staff_info`.`title_id` = `ssms`.`t_title`.`title_id`))